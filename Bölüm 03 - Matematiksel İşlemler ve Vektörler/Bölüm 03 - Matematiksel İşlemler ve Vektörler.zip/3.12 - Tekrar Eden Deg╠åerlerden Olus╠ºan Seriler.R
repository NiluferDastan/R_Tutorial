

rep(4 , 14)

r <- rep(4 , 14)
r
length(r)

x <- c(34,23,45,67)
x
rep(x , 2) 


rep(x , each = 2)

v <- rep(x , each = 5)
v
length(v)

sample(v)

t <- sample(v)
