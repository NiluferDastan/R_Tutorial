
x <- c(1,2,3,4,5,6,7)

# Vektor uzunluğunu veren fonksiyon
length(x)

x1 <- c(11,22,33,44,55,66,67,56,5,6,5,4,34)
length(x1)

x2 <- c('A' ,'B' ,'C' ,'D',
        'A' ,'B' ,'C' ,'D',
        'A' ,'B' ,'C' ,'D',
        'A' ,'B' ,'C' ,'D',
        'A' ,'B' ,'C' ,'D',
        'A' ,'B' ,'C' ,'D',
        'A' ,'B' ,'C' ,'D',
        'A' ,'B' ,'C' ,'D',
        'A' ,'B' ,'C' ,'D',
        'A' ,'B' ,'C' ,'D'
        )

# Vektor uzunluğu
length(x2)
x2[40]

x2[length(x2)]

len <- length(x2)
len

x2[len]

x2[len-1]

x2[len-3]
