
x <- c(12,54,67,43,35)

x + 5
x - 5
x / 5
x * 5
x **2
x **3

# Yeni bir vektore atama işlemi 
y <- x**2
x
y

# İki vektor üzerinden matematik işlemleri
z <- x + 15
z
x
x + z
x * z
x / z

x1 <- c(13,24,35,56)
x2 <- c(12,23)

x1 + x2
x1 * x2

# (13 , 24 , 35 , 36)
# (12 , 23) (12 , 23)

x3 <- c(13,24,35,56)
x4 <- c(12,23 ,24)

x3 + x4
