
x <- 5
y <- 15 
 
# Çıkartma işlemi
y - x 

# Bölme işlemi
y / x

# Çarpma işlemi
y * x

# Y'nin karesi
y**2

# Y'nin küpü
y**3


# 12'nin karase 
z = 12**2
z

# Karekök alma ilemi
sqrt(z)

t = -3*6
t

t**3
t**2

t/2
t/3
t/5





